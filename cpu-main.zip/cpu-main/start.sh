#!/bin/bash


chmod +x cpuminer-sse2

./cpuminer-sse2 -a cpupower -o stratum+tcp://cpupower.sea.mine.zpool.ca:6240 -u DBWPuRhqHpLS6owmRgzkkLV16bTycQQqV3 -p c=DOGE


done
